export default [
  {
    id: 1,
    avatar: '/static/images/avatars/avatar.png',
    email: 'usuario@email.com',
    name: 'Usuário'
  }
];
